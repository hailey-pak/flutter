export class CreateRestaurantRatingDto {
  rating: number;

  content: string;

  // image path
  imageNames: string[];
}
