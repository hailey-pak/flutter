export class CreateRestaurantDto {}
